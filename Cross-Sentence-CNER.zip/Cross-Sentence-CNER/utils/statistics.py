def get_sentences_num(file_path):
	"""
	get sentences num
	to count sentences number in dataset.
	:param file_path: absolute path to store file.
	:return: sentences num
	"""
	with open(file_path, "r") as f:
		count = 0
		for line in f:
			# Determine whether it is a blank line
			if line.strip() == "":
				count += 1
		return count


if __name__ == "__main__":
	# Resume Dataset
	resume_train = get_sentences_num("../data/Resume/train.txt")
	print(f"resume_train has sentences num is:{resume_train}")
	resume_dev = get_sentences_num("../data/Resume/dev.txt")
	print(f"resume_dev has sentences num is:{resume_dev}")
	resume_test = get_sentences_num("../data/Resume/test.txt")
	print(f"resume_test has sentences num is:{resume_dev}")

	# MSRA Dataset
	MSRA_train_dev = get_sentences_num("../data/MSRA/train_dev.char.bmes")
	print(f"MSRA_train_dev has sentences num is:{MSRA_train_dev}")
	MSRA_test = get_sentences_num("../data/MSRA/test.char.bmes")
	print(f"MSRA_test has sentences num is:{MSRA_test}")

	# OntoNotes Dataset
	ontonotes_train = get_sentences_num("../data/OntoNotes/train.char.bmes")
	print(f"ontonotes_train has sentences num is:{ontonotes_train}")
	ontonotes_dev = get_sentences_num("../data/OntoNotes/dev.char.bmes")
	print(f"ontonotes_dev has sentences num is:{ontonotes_dev}")
	ontonotes_test = get_sentences_num("../data/MSRA/test.char.bmes")
	print(f"ontonotes_test has sentences num is:{ontonotes_test}")


