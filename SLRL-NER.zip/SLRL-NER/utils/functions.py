# -*- coding: utf-8 -*-

import sys
import numpy as np
import re
from utils.alphabet import Alphabet
# from transformers.tokenization_bert import BertTokenizer
from transformers.models.bert.tokenization_bert import BertTokenizer

NULLKEY = "-null-"


def normalize_word(word):
    new_word = ""
    # 遍历word中的每一个char
    for char in word:
        # 如果只由数字组成
        if char.isdigit():
            new_word += '0'
        else:
            new_word += char
    return new_word


# gaz:ctb.50d.vec
def read_instance_with_gaz(num_layer, input_file, gaz, word_alphabet, radical_alphabet, radical_count,
                           char_alphabet,
                           gaz_alphabet, gaz_count, gaz_split, label_alphabet, number_normalized, max_sent_length,
                           char_padding_size=-1, char_padding_symbol='</pad>'):
    # tokenizer = BertTokenizer.from_pretrained('bert-base-chinese', do_lower_case=True)
    tokenizer = BertTokenizer.from_pretrained('hfl/chinese-bert-wwm-ext', do_lower_case=True)
    in_lines = open(input_file, 'r', encoding="utf-8").readlines()
    instence_texts = []
    instence_Ids = []
    words = []
    radicals = []
    chars = []
    labels = []
    word_Ids = []
    radical_Ids = []
    char_Ids = []
    label_Ids = []
    for idx in range(len(in_lines)):
        line = in_lines[idx]
        if len(line) > 2:
            pairs = line.strip().split()
            word = pairs[0]
            if number_normalized:
                word = normalize_word(word)
            label = pairs[-1]
            radicals.append(word)
            words.append(word)
            labels.append(label)
            word_Ids.append(word_alphabet.get_index(word))
            radical_index = radical_alphabet.get_index(word)
            radical_Ids.append(radical_index)
            label_Ids.append(label_alphabet.get_index(label))
            char_list = []
            char_Id = []
            for char in word:
                char_list.append(char)
            if char_padding_size > 0:
                char_number = len(char_list)
                if char_number < char_padding_size:
                    char_list = char_list + [char_padding_symbol] * (char_padding_size - char_number)
                assert (len(char_list) == char_padding_size)
            else:
                ### not padding
                pass
            for char in char_list:
                char_Id.append(char_alphabet.get_index(char))
            chars.append(char_list)
            char_Ids.append(char_Id)

        else:
            # 如果句子长度不足最大长度并且句子长度大于0
            if ((max_sent_length < 0) or (len(words) < max_sent_length)) and (len(words) > 0):
                gaz_Ids = []
                layergazmasks = []
                gazchar_masks = []
                w_length = len(words)
                # gazs包含BMES词集
                gazs = [[[] for i in range(6)] for _ in
                        range(w_length)]  # gazs:[c1,c2,...,cn]  ci:[B,M,E,S]  B/M/E/S :[w_id1,w_id2,...]  None:0
                # gazs_count为BMES计数 (句子长度,6,1)
                gazs_count = [[[] for i in range(6)] for _ in range(w_length)]

                gaz_char_Id = [[[] for i in range(6)] for _ in
                               range(
                                   w_length)]  ## gazs:[c1,c2,...,cn]  ci:[B,M1,M2,Mo,E,S]  B/M1/M2/Mo/E/S :[[w1c1,w1c2,...],[],...]

                max_gazlist = 0
                max_gazcharlen = 0
                for idx in range(w_length):
                    # matched_list：与词典匹配词的列表
                    matched_list = gaz.enumerateMatchList(words[idx:])
                    # matched_length:与词典匹配词的长度list
                    matched_length = [len(a) for a in matched_list]
                    # 匹配词对应id
                    matched_Id = [gaz_alphabet.get_index(entity) for entity in matched_list]

                    if matched_length:
                        max_gazcharlen = max(max(matched_length), max_gazcharlen)

                    for w in range(len(matched_Id)):
                        gaz_chars = []
                        g = matched_list[w]  # g:取出的每一个候选词
                        for c in g:  # 遍历候选词中的每一个字
                            gaz_chars.append(word_alphabet.get_index(c))

                        if matched_length[w] == 1:  ## Single  5
                            gazs[idx][5].append(matched_Id[w])
                            # gaz_count:训练集，测试集，验证集中的匹配词及出现次数
                            # gazs_count：(句子长度，6，词出现次数)
                            gazs_count[idx][5].append(1)
                            gaz_char_Id[idx][5].append(gaz_chars)
                        else:  # 不是单字符的情况
                            gazs[idx][0].append(matched_Id[w])  ## Begin
                            gazs_count[idx][0].append(gaz_count[matched_Id[w]])
                            gaz_char_Id[idx][0].append(gaz_chars)
                            wlen = matched_length[w]
                            gazs[idx + wlen - 1][4].append(matched_Id[w])  ## End
                            gazs_count[idx + wlen - 1][4].append(gaz_count[matched_Id[w]])
                            gaz_char_Id[idx + wlen - 1][4].append(gaz_chars)
                            # 若存在中间字符
                            middle_count = wlen - 2  # 中间字符的个数
                            if middle_count == 1:
                                gazs[idx + 1][1].append(matched_Id[w])  # Middle1_1
                                gazs_count[idx + 1][1].append(gaz_count[matched_Id[w]])
                                gaz_char_Id[idx + 1][1].append(gaz_chars)

                            elif middle_count == 2:
                                gazs[idx + 1][1].append(matched_Id[w])  # Middle_1
                                gazs_count[idx + 1][1].append(gaz_count[matched_Id[w]])
                                gaz_char_Id[idx + 1][1].append(gaz_chars)
                                gazs[idx + 2][2].append(matched_Id[w])  # Middle_2
                                gazs_count[idx + 2][2].append(gaz_count[matched_Id[w]])
                                gaz_char_Id[idx + 2][2].append(gaz_chars)

                            elif middle_count >= 3:  # middle_count >= 3:
                                gazs[idx + 1][1].append(matched_Id[w])  # Middle_1
                                gazs_count[idx + 1][1].append(gaz_count[matched_Id[w]])
                                gaz_char_Id[idx + 1][1].append(gaz_chars)
                                gazs[idx + 2][2].append(matched_Id[w])  # Middle_2
                                gazs_count[idx + 2][2].append(gaz_count[matched_Id[w]])
                                gaz_char_Id[idx + 2][2].append(gaz_chars)
                                for l in range(2, middle_count):  # Middle_other
                                    gazs[idx + l + 1][3].append(matched_Id[w])
                                    gazs_count[idx + l + 1][3].append(gaz_count[matched_Id[w]])
                                    gaz_char_Id[idx + l + 1][3].append(gaz_chars)

                            # for l in range(wlen - 2):
                            #     gazs[idx + l + 1][1].append(matched_Id[w])  ## Middle
                            #     gazs_count[idx + l + 1][1].append(gaz_count[matched_Id[w]])
                            #     gaz_char_Id[idx + l + 1][1].append(gaz_chars)

                    for label in range(6):
                        # 若B/M1/M2/Mo/E/S位置为None
                        if not gazs[idx][label]:
                            # 零填充
                            gazs[idx][label].append(0)
                            gazs_count[idx][label].append(1)  # 零填充同样计数
                            gaz_char_Id[idx][label].append([0])

                        max_gazlist = max(len(gazs[idx][label]), max_gazlist)

                    matched_Id = [gaz_alphabet.get_index(entity) for entity in matched_list]  # 词号
                    if matched_Id:
                        gaz_Ids.append([matched_Id, matched_length])
                    else:
                        gaz_Ids.append([])

                ## batch_size = 1
                for idx in range(w_length):
                    gazmask = []
                    gazcharmask = []

                    for label in range(6):
                        label_len = len(gazs[idx][label])
                        count_set = set(gazs_count[idx][label])
                        if len(count_set) == 1 and 0 in count_set:
                            gazs_count[idx][label] = [1] * label_len

                        mask = label_len * [0]
                        mask += (max_gazlist - label_len) * [1]

                        gazs[idx][label] += (max_gazlist - label_len) * [0]  ## padding
                        gazs_count[idx][label] += (max_gazlist - label_len) * [0]  ## padding

                        char_mask = []
                        for g in range(len(gaz_char_Id[idx][label])):
                            glen = len(gaz_char_Id[idx][label][g])
                            charmask = glen * [0]
                            charmask += (max_gazcharlen - glen) * [1]
                            char_mask.append(charmask)
                            gaz_char_Id[idx][label][g] += (max_gazcharlen - glen) * [0]
                        gaz_char_Id[idx][label] += (max_gazlist - label_len) * [[0 for i in range(max_gazcharlen)]]
                        char_mask += (max_gazlist - label_len) * [[1 for i in range(max_gazcharlen)]]

                        gazmask.append(mask)
                        gazcharmask.append(char_mask)
                    layergazmasks.append(gazmask)
                    gazchar_masks.append(gazcharmask)

                texts = ['[CLS]'] + words + ['[SEP]']
                bert_text_ids = tokenizer.convert_tokens_to_ids(texts)

                instence_texts.append([words, radicals, chars, gazs, labels])
                instence_Ids.append(
                    [word_Ids, radical_Ids, char_Ids, gaz_Ids, label_Ids, gazs, gazs_count, gaz_char_Id,
                     layergazmasks,
                     gazchar_masks, bert_text_ids])

            words = []
            radicals = []
            chars = []
            labels = []
            word_Ids = []
            radical_Ids = []
            char_Ids = []
            label_Ids = []

    return instence_texts, instence_Ids


def build_pretrain_embedding(embedding_path, word_alphabet, embedd_dim=100, norm=True):
    embedd_dict = dict()
    if embedding_path != None:
        embedd_dict, embedd_dim = load_pretrain_emb(embedding_path)

    scale = np.sqrt(3.0 / embedd_dim)
    pretrain_emb = np.empty([word_alphabet.size(), embedd_dim])
    perfect_match = 0
    case_match = 0
    not_match = 0
    # 产生[1, embedd_dim]个(-scale, scale)之间的数
    pretrain_emb[0, :] = np.random.uniform(-scale, scale, [1, embedd_dim])
    for word, index in word_alphabet.instance2index.items():
        if word in embedd_dict:
            if norm:
                pretrain_emb[index, :] = norm2one(embedd_dict[word])
            else:
                pretrain_emb[index, :] = embedd_dict[word]
            perfect_match += 1
        elif word.lower() in embedd_dict:
            if norm:
                pretrain_emb[index, :] = norm2one(embedd_dict[word.lower()])
            else:
                pretrain_emb[index, :] = embedd_dict[word.lower()]
            case_match += 1
        else:
            pretrain_emb[index, :] = np.random.uniform(-scale, scale, [1, embedd_dim])
            not_match += 1
    pretrained_size = len(embedd_dict)
    print("Embedding:\n     pretrain word:%s, prefect match:%s, case_match:%s, oov:%s, oov%%:%s" % (
        pretrained_size, perfect_match, case_match, not_match, (not_match + 0.) / word_alphabet.size()))
    return pretrain_emb, embedd_dim


def norm2one(vec):
    root_sum_square = np.sqrt(np.sum(np.square(vec)))
    return vec / root_sum_square


def load_pretrain_emb(embedding_path):
    embedd_dim = -1
    embedd_dict = dict()
    with open(embedding_path, 'r', encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if len(line) == 0:
                continue
            tokens = line.split()
            if embedd_dim < 0:
                embedd_dim = len(tokens) - 1
            else:
                assert (embedd_dim + 1 == len(tokens))
            embedd = np.empty([1, embedd_dim])
            embedd[:] = tokens[1:]
            embedd_dict[tokens[0]] = embedd
    return embedd_dict, embedd_dim
