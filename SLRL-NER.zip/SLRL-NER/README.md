# SLRL-NER
This is the implementation of our paper "**SLRL-NER: An exp-SoftLexicon Lattice Model Integrating**

**Radical-Level Features for Chinese NER**", which fuses radical-level , character and word information for Chinese NER.

# Source code description
## Requirement:
Python 3.6
Pytorch 0.4.1

## Input format:
CoNLL format, with each character and its label split by a whitespace in a line. The "BMES" tag scheme is prefered.

别 O 

错 O

过 O

邻 O

近 O

大 B-LOC

鹏 M-LOC

湾 E-LOC

的 O

湿 O

地 O

## Pretrain embedding:
The pretrained embeddings(word embedding) are the same with [Lattice LSTM](https://www.aclweb.org/anthology/P18-1144)

Radical-Level features using Lattice LSTM character embedding and generates max_pool_radical_1 / max_pool_radical_2.

## Run the code:
1.Download the three datasets in `data/OntoNotesNER`, `data/ResumeNER` and `data/WeiboNER`, respectively.

2.To train on the three datasets:

- To train on OntoNotes:(Due to copyright issues, we are unable to provide the OntoNotes dataset, please apply for a license at [LDC](https://www.ldc.upenn.edu/).)

`python main.py --train data/OntoNotesNER/train.char.bmes --dev data/OntoNotesNER/dev.char.bmes --test data/OntoNotesNER/test.char.bmes --modelname OntoNotes --savedset data/OntoNotes.dset --hidden_dim 400 ` 

- To train on Resume:

`python main.py --train data/ResumeNER/train.char.bmes --dev data/ResumeNER/dev.char.bmes --test data/ResumeNER/test.char.bmes --modelname Resume --savedset data/Resume.dset --hidden_dim 200`

- To train on Weibo:

`python main.py --train data/WeiboNER/train.all.bmes --dev data/WeiboNER/dev.all.bmes --test data/WeiboNER/test.all.bmes --modelname Weibo --savedset data/Weibo.dset --lr=0.005 --hidden_dim 200`

**notes: max_pool_radical_1.vec for OntoNotes4.0 , max_pool_radical_2.vec for WeiboNER and ResumeNER.**

3.To train/test your own data: modify the command with your file path and run.

